(function () {
  'use strict';

  function initSlider() {
    const slider = document.getElementById('slider');
    if (!slider) return;

    const slides = slider.querySelectorAll('.slide');
    if (slides.length === 0) return;

    let currentSlide = 0;
    let slideInterval;

    function showSlide(index) {
      // Remove active and zooming from all
      slides.forEach(slide => {
        slide.classList.remove('zooming');
        slide.classList.remove('active');
      });
      
      // Show new slide
      slides[index].classList.add('active');
      
      setTimeout(() => {
        slides[index].classList.add('zooming');
      }, 100);
      
      currentSlide = index;
    }

    function nextSlide() {
      let next = (currentSlide + 1) % slides.length;
      showSlide(next);
    }

    function startSlider() {
      slideInterval = setInterval(nextSlide, 5000); // 5 seconds
    }

    function stopSlider() {
      clearInterval(slideInterval);
    }

    // Pause on hover
    slider.addEventListener('mouseenter', stopSlider);
    slider.addEventListener('mouseleave', startSlider);

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
      if (e.key === 'ArrowLeft') {
        stopSlider();
        let prev = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(prev);
        startSlider();
      } else if (e.key === 'ArrowRight') {
        stopSlider();
        nextSlide();
        startSlider();
      }
    });

    // Start
    startSlider();
  }

  // Run when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSlider);
  } else {
    initSlider();
  }

})();
